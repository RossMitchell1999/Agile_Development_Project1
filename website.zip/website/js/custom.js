function validateCode() {
    var code = document.getElementById("code");
    
    if (code.checked) {
        // alert("this works");
        
        var input = document.getElementById("inputSearchCriteria").value;
        var len = input.length;

        if (len == 3) {
            // alert("this works");            
            inputInt = parseInt(input);
            
            if (inputInt < 000 || inputInt > 999) {
                alert("Invalid Code");
                return false;
            }
            else {
                return true;
            }
        }
        else {
            alert("Invalid Code");
            return false;
        }
    }
}
        
function test() {
    alert("this works");
}
